Aozora Tavo Novel Presets — 1.0.4

This package contains the updated 1.0.4 preset JSON files.
Import the desired preset JSON into Tavo.
The files are the latest versions from the repository main branch.
